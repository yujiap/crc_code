/* 

This code contains six implementations of the cncore function.
cncore1 and cncore2 are optimized for memory, while cncore3 and cncore4
are optimized for speed:

v1: G != Gb
v2: G = Gb
v3: G != Gb , p < m/2
v4: G != Gb , p !< m/2
v5: G = Gb , p < m/2
v6: G = Gb , p !< m/2

The associated wrappers are in wrappers.R.

 */

# include <stdio.h>


/* auxillary functions */


// A mxp, B pxl
void multiply (double *A, double *B, double *C, int *m, int *p, int *l){
	for (int i = 0; i < *m; i++){
		for (int j = 0; j < *l; j++){
			int ij; ij = (j * *m) + i;
			for (int k = 0; k < *p; k++){
				int ik; ik = (k * *m) + i;
				int kj; kj = (j * *p) + k;
				*(C + ij) += *(A + ik) * *(B + kj);
			}
		}
	}
}


// A pxm, B pxl, C mxl
void multiplyAtB (double *A, double *B, double *C, int *m, int *p, int *l){
	for (int i = 0; i < *m; i++){
		for (int j = 0; j < *l; j++){
			int ij; ij = (j * *m) + i;
			*(C + ij) = 0;
			for (int k = 0; k < *p; k++){
				int ik; ik = (i * *p) + k;
				int kj; kj = (j * *p) + k;
				*(C + ij) += *(A + ik) * *(B + kj);
			}
		}
	}
}

/*
X mxp
Ginv mxm
A mxp
multiply kth row of Ginv with A, store the resulting 1xp vector as
the 1st row of X
*/
void rowMatMultiply (double *X, double *Ginv, double *A, int *m, int *p, int *k){
	// zero out 1st row of X
	for (int j = 0; j < *p; j++){
		*(X + (j * *m)) = 0;
	}

	// kth row of Ginv times A
	for (int i = 0; i < *m; i++){
		double coeff; coeff = *(Ginv + (i * *m) + *k);
		for (int j = 0; j < *p; j++){
			int ij; ij = (j * *m) + i;
			*(X + (j * *m)) += coeff * *(A + ij); // always write to 1st row
		}
	}
}


// assume y is 1xm
void rowMatMultiply3 (double *y, double *X, double *B, int *m, int *p, int *k){
	// zero out y
	for (int j = 0; j < *m; j++){
		*(y + j) = 0;
	}

	// kth row of X times B
	for (int i = 0; i < *p; i++){
		double coeff; coeff = *(X + (i * *m) + *k);
		for (int j = 0; j < *m; j++){
			int ij; ij = (j * *p) + i;
			*(y + j) += coeff * *(B + ij);
		}
	}
}


// here k is an int, not a int*. for testing in R, use the function above.
// assume y is 1xm
void rowMatMultiply3n (double *y, double *X, double *B, int *m, int *p, int k){
	// zero out y
	for (int j = 0; j < *m; j++){
		*(y + j) = 0;
	}

	// kth row of X times B
	for (int i = 0; i < *p; i++){
		double coeff; coeff = *(X + (i * *m) + k);
		for (int j = 0; j < *m; j++){
			int ij; ij = (j * *p) + i;
			*(y + j) += coeff * *(B + ij);
		}
	}
}


void multiply5 (double *y, double *Ginv, double *H, int *m, int *k){
	// zero out y
	for (int j = 0; j < *m; j++){
		*(y + j) = 0;
	}

	// kth row of Ginv times H
	for (int i = 0; i < *m; i++){
		double coeff; coeff = *(Ginv + (i * *m) + *k);
		for (int j = 0; j < *m; j++){
			int ij; ij = (j * *m) + i;
			*(y + j) += coeff * *(H + ij);
		}
	}
}


/* cncore functions */


void cncore1_ (double *Cn, double *Ginv, double *Gbinv, 
	double *GinvH, double *GbinvH, double *H, int *m){

	for (int i = 0; i < *m; i++){
		int ii; ii = i * (*m + 1);
		double sca1; sca1 = 1 / *(Gbinv + ii);
		double sca2; sca2 = (1 / (*(Ginv + ii) - *(GinvH + ii))) * (*(H + ii) - *(GbinvH + ii) / *(Gbinv + ii));

		for (int j = 0; j < *m; j++){
			int ij; ij = (j * *m) + i;
			*(Cn + ij) = sca1 * (*(Gbinv + ij) - *(GbinvH + ij)) +
						*(H + ij) +
						sca2 * (*(GinvH + ij) - *(Ginv + ij));
		}
	}
}


void cncore2_ (double *Cn, double *Ginv, double *GinvH, double *H, int *m){

	for (int i = 0; i < *m; i++){
		int ii; ii = i * (*m + 1);
		double sca1; sca1 = 1 / *(Ginv + ii);
		double sca2; sca2 = (1 / (*(Ginv + ii) - *(GinvH + ii))) * (*(H + ii) - *(GinvH + ii) / *(Ginv + ii));
		double sca3 = sca1 - sca2;

		for (int j = 0; j < *m; j++){
			int ij; ij = (j * *m) + i;
			*(Cn + ij) = sca3 * (*(Ginv + ij) - *(GinvH + ij)) + *(H + ij);
		}
	}
}


void cncore3_ (double *X,
	double *Ginv, double *Gbinv, 
	double *H, double *a, double *b, // H is a 1xm workspace; a,b are 1xm workspaces
	double *solveXtGinvX, // delete later 
	double *A, double *B, // mxp and pxm workspaces
	int *m, int *p){

	// calculate Ginv, Gbinv in place (later)
	// args Ginv, Gbinv will be G and Gb respectively
	
	// calculate solveXtGinvX and put in B (later)
	// works bc assume p < m
	// also solveXtGinvX is symmetric, so only iterate over 1/2 of it
	for (int i = 0; i < *p; i++){
		for (int j = i; j < *p; j++){
			int ij; ij = (j * *p) + i;
			int ji; ji = (i * *p) + j;
			*(B + ij) = *(solveXtGinvX + ij);
			*(B + ji) = *(solveXtGinvX + ij);
		}
	}

	// calculate XsolveXtGinvX, put in A
	multiply(X, B, A, m, p, p);

	// calculate XtGinv, put in B
	multiplyAtB(X, Ginv, B, p, m, m);

	for (int i = 0; i < *m; i++){
		int ii; ii = i * (*m + 1);
		double sca1;
		double sca2;

		// calculate ith row of Ginv %*% A, a 1xp vector, store in 1st row of X (tmp res)
		rowMatMultiply(X, Ginv, A, m, p, &i);
		// calculate ith row of GinvH = GinvAB using prev 1xp vector, store in a
		rowMatMultiply3n(a, X, B, m, p, 0);

		// calculate ith row of Gbinv %*% A, store in 1st row of X (tmp res)
		rowMatMultiply(X, Gbinv, A, m, p, &i);
		// calculate ith row of GbinvH = GbinvAB, store in b
		rowMatMultiply3n(b, X, B, m, p, 0);

		// calculate ith row of A %*% B, store in 1st and only col of H
		rowMatMultiply3(H, A, B, m, p, &i);

		// Compute scalars
		sca1 = 1 / *(Gbinv + ii);
		sca2 = (1 / (*(Ginv + ii) - *(a + i))) * (*(H + i) - *(b + i) / *(Gbinv + ii));

		// calculate ith row of crossnormalization matrix; overwrite ith row of Ginv
		for (int j = 0; j < *m; j++){
			int ij; ij = (j * *m) + i;
			*(Ginv + ij) = sca1 * (*(Gbinv + ij) - *(b + j)) +
						*(H + j) +
						sca2 * (*(a + j) - *(Ginv + ij));
		}
	}
}


void cncore4_ (double *X,
	double *Ginv, double *Gbinv, 
	double *H, double *a, double *b, // H is a mxm workspace; a,b are 1xm workspaces
	double *solveXtGinvX, // delete later
	int *m, int *p){

	// calculate Ginv, Gbinv in place (later)
	// args Ginv, Gbinv will be G and Gb respectively
	
	// calculate solveXtGinvX and put in H (later)
	// works bc assume p < m
	// also solveXtGinvX is symmetric, so only iterate over 1/2 of it
	for (int i = 0; i < *p; i++){
		for (int j = i; j < *p; j++){
			int ij; ij = (j * *p) + i;
			int ji; ji = (i * *p) + j;
			int ij2; ij2 = (j * *m) + i;
			int ji2; ji2 = (i * *m) + j;
			*(H + ij2) = *(solveXtGinvX + ij);
			*(H + ji2) = *(solveXtGinvX + ij);
		}
	}

	// calculate solveXtGinvX %*% Xt, put in H (upper pxp)
	for (int i = 0; i < *p; i++){
		// put all coefficients in workspace in prep to overwrite ith row of H
		// also zero out ith row of H in prep to overwrite it
		for (int j = 0; j < *p; j++){
			*(a + j) = *(H + (*m * j) + i);
			*(H + (*m * j) + i) = 0;
		}

		for (int j = 0; j < *p; j++){
			for (int k = 0; k < *m; k++){
				int ik; ik = (k * *m) + i;
				int kj; kj = (j * *m) + k;
				*(H + ik) += *(a + j) * *(X + kj);
			}
		}
	}

	// calculate (solveXtGinvX %*% Xt) %*% Ginv, put in H (upper pxm)
	for (int i = 0; i < *p; i++){
		for (int j = 0; j < *m; j++){
			*(a + j) = *(H + (*m * j) + i);
			*(H + (*m * j) + i) = 0;
		}

		for (int j = 0; j < *m; j++){
			for (int k = 0; k < *m; k++){
				int ik; ik = (k * *m) + i;
				int kj; kj = (j * *m) + k;
				*(H + ik) += *(a + j) * *(Ginv + kj);
			}
		}
	}

	// calculate X %*% solveXtGinvX %*% Xt %*% Ginv, put in H (mxm)
	for (int i = 0; i < *m; i++){
		// put coeffcients (ith col of H) in workspace
		for (int j = 0; j < *p; j++){
			*(a + j) = *(H + (i * *m) + j);
			*(H + (i * *m) + j) = 0;
		}

		for (int j = 0; j < *p; j++){
			for (int k = 0; k < *m; k++){
				int ki; ki = (i * *m) + k;
				int kj; kj = (j * *m) + k;
				*(H + ki) += *(a + j) * *(X + kj);
			}
		}
	}

	// compute rows of the Cn matrix
	for (int i = 0; i < *m; i++){
		int ii; ii = i * (*m + 1);
		double sca1;
		double sca2;

		// calculate ith row of GinvH, store in a
		multiply5(a, Ginv, H, m, &i);

		// calculate ith row of GbinvH, store in b
		multiply5(b, Gbinv, H, m, &i);

		// finish computing scalars
		sca1 = 1 / *(Gbinv + ii);
		sca2 = (1 / (*(Ginv + ii) - *(a + i))) * (*(H + ii) - *(b + i) / *(Gbinv + ii));

		// calculate ith row of crossnormalization matrix; overwrite ith row of Ginv
		for (int j = 0; j < *m; j++){
			int ij; ij = (j * *m) + i;
			*(Ginv + ij) = sca1 * (*(Gbinv + ij) - *(b + j)) +
						*(H + ij) +
						sca2 * (*(a + j) - *(Ginv + ij));

		//*(Ginv + ii) = 1;
		}
	}
}


void cncore5_ (double *X,
	double *Ginv,
	double *H, double *a, // H is a 1xm workspace; a is 1xm workspace
	double *solveXtGinvX, // delete later 
	double *A, double *B, // mxp and pxm workspaces
	int *m, int *p){

	// calculate Ginv in place (later)
	// args Ginv will be G

	// calculate solveXtGinvX and put in B (later)
	// works bc assume p < m
	// also solveXtGinvX is symmetric, so only iterate over 1/2 of it
	for (int i = 0; i < *p; i++){
		for (int j = i; j < *p; j++){
			int ij; ij = (j * *p) + i;
			int ji; ji = (i * *p) + j;
			*(B + ij) = *(solveXtGinvX + ij);
			*(B + ji) = *(solveXtGinvX + ij);
		}
	}

	// calculate XsolveXtGinvX, put in A
	multiply(X, B, A, m, p, p);

	// calculate XtGinv, put in B
	multiplyAtB(X, Ginv, B, p, m, m);

	for (int i = 0; i < *m; i++){
		int ii; ii = i * (*m + 1);
		double sca3;

		// calculate ith row of Ginv %*% A, a 1xp vector, store in 1st row of X (tmp res)
		rowMatMultiply(X, Ginv, A, m, p, &i);
		// calculate ith row of GinvH = GinvAB using prev 1xp vector, store in a
		rowMatMultiply3n(a, X, B, m, p, 0);

		// calculate ith row of A %*% B, store in 1st and only col of H
		rowMatMultiply3(H, A, B, m, p, &i);

		// finish computing scalars
		sca3 = (1 / *(Ginv + ii)) - (1 / (*(Ginv + ii) - *(a + i))) * (*(H + i) - *(a + i) / *(Ginv + ii));

		// calculate ith row of crossnormalization matrix; overwrite ith row of Ginv
		for (int j = 0; j < *m; j++){
			int ij; ij = (j * *m) + i;
			*(Ginv + ij) = sca3 * (*(Ginv + ij) - *(a + j)) + *(H + j);
		}
	}
}


void cncore6_ (double *X,
	double *Ginv, 
	double *H, double *a, // H is a mxm workspace; a is 1xm workspace
	double *solveXtGinvX, // delete later
	int *m, int *p){

	// calculate Ginv in place (later)
	// arg Ginv will be G
	
	// calculate solveXtGinvX and put in H (later)
	// works bc assume p < m
	// also solveXtGinvX is symmetric, so only iterate over 1/2 of it
	for (int i = 0; i < *p; i++){
		for (int j = i; j < *p; j++){
			int ij; ij = (j * *p) + i;
			int ji; ji = (i * *p) + j;
			int ij2; ij2 = (j * *m) + i;
			int ji2; ji2 = (i * *m) + j;
			*(H + ij2) = *(solveXtGinvX + ij);
			*(H + ji2) = *(solveXtGinvX + ij);
		}
	}

	// calculate solveXtGinvX %*% Xt, put in H (upper pxp)
	for (int i = 0; i < *p; i++){
		// put all coefficients in workspace in prep to overwrite ith row of H
		// also zero out ith row of H in prep to overwrite it
		for (int j = 0; j < *p; j++){
			*(a + j) = *(H + (*m * j) + i);
			*(H + (*m * j) + i) = 0;
		}

		for (int j = 0; j < *p; j++){
			for (int k = 0; k < *m; k++){
				int ik; ik = (k * *m) + i;
				int kj; kj = (j * *m) + k;
				*(H + ik) += *(a + j) * *(X + kj);
			}
		}
	}

	// calculate (solveXtGinvX %*% Xt) %*% Ginv, put in H (upper pxm)
	for (int i = 0; i < *p; i++){
		for (int j = 0; j < *m; j++){
			*(a + j) = *(H + (*m * j) + i);
			*(H + (*m * j) + i) = 0;
		}

		for (int j = 0; j < *m; j++){
			for (int k = 0; k < *m; k++){
				int ik; ik = (k * *m) + i;
				int kj; kj = (j * *m) + k;
				*(H + ik) += *(a + j) * *(Ginv + kj);
			}
		}
	}

	// calculate X %*% solveXtGinvX %*% Xt %*% Ginv, put in H (mxm)
	for (int i = 0; i < *m; i++){
		// put coeffcients (ith col of H) in workspace
		for (int j = 0; j < *p; j++){
			*(a + j) = *(H + (i * *m) + j);
			*(H + (i * *m) + j) = 0;
		}

		for (int j = 0; j < *p; j++){
			for (int k = 0; k < *m; k++){
				int ki; ki = (i * *m) + k;
				int kj; kj = (j * *m) + k;
				*(H + ki) += *(a + j) * *(X + kj);
			}
		}
	}

	// compute rows of the Cn matrix
	for (int i = 0; i < *m; i++){
		int ii; ii = i * (*m + 1);
		double sca3;

		// calculate ith row of GinvH, store in a
		multiply5(a, Ginv, H, m, &i);

		// finish computing scalars
		sca3 = (1 / *(Ginv + ii)) - (1 / (*(Ginv + ii) - *(a + i))) * (*(H + ii) - *(a + i) / *(Ginv + ii));

		// calculate ith row of crossnormalization matrix; overwrite ith row of Ginv
		for (int j = 0; j < *m; j++){
			int ij; ij = (j * *m) + i;
			*(Ginv + ij) = sca3 * (*(Ginv + ij) - *(a + j)) + *(H + ij);
		}
	}
}
