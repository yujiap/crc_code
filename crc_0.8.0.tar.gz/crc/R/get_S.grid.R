get_S.grid = function(S.grid, Z) {
  p = ncol(Z)
  cap.N = sqrt(p)
  if (S.grid == "default") {
    grid.spacing.log2 = 0.5
    S.grid = unique(round(2^(seq(0, log2(cap.N), by=grid.spacing.log2))))
  }

  ## For testing purposes only!
  # cap.N = p
  # S.grid = 2^(0:floor(log(cap.N, 2)))

  return(S.grid)
}
