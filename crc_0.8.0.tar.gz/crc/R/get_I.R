get_I = function(classes)
{
  T = factor(classes)
  I = model.matrix(~T-1)  # Sort the columns alphabetically?
  colnames(I) = levels(T)
  return(I)
}