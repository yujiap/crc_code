get_prior = function(prior, I) 
{
  if (is.null(prior)) prior = "empirical"
  if (prior == "empirical") prior = apply(I, 2, sum)/nrow(I)
  if (prior == "flat") prior = rep(1/ncol(I), ncol(I))
  return(prior)
}
