choose_S_scores = function(Ss, Ls, I) 
{
    ns = ncol(Ss)
    ml = solve(t(I)%*%I)%*%t(I)%*%Ls
    ms = solve(t(I)%*%I)%*%t(I)%*%Ss
    Lr = Ls - I%*%ml
    Sr = Ss - I%*%ms
    ml = ml[2] - ml[1]
    ms = ms[2,] - ms[1,]
    ss = apply(Sr^2,2,sum)
    sl = sum(Lr^2)
    co = t(Lr)%*%Sr
    v = (sl*ms^2 - 2*co*ms*ml + ss*ml^2)/(ss*sl-co^2)
    return(list("idx"=order(v)[ns], "v"=v))
}
