# Remove "my_lda" function and just integrate it into here?  Or is it used anywhere else?
crcC = function(I, S.LOO, L.LOO, prior) {
  n = nrow(I)
  n1 = sum(I[,1])
  n2 = sum(I[,2])
  Sc = cbind(S.LOO, L.LOO)
  mu = t(I) %*% Sc / c(n1, n2)
  R_I = diag(n) - I %*% solve(t(I) %*% I) %*% t(I)
  Sinv = solve(crossprod(R_I %*% Sc) / (n-2))
  beta1 = Sinv %*% (mu[2,]-mu[1,])
  beta0 = as.numeric(log(prior[2]/prior[1]) - 0.5*t(mu[2,]+mu[1,]) %*% beta1)
  scores = Sc %*% beta1 + beta0
  return(list("beta1"=beta1, "beta0"=beta0, "scores"=scores))
}