crcL = function(I, G.sr.inv, G.sr, lambda, prior) {
  n = nrow(I)
  n1 = sum(I[,1])
  n2 = sum(I[,2])
  R_I = diag(n) - I %*% solve(t(I)%*%I)%*% t(I)

  G.sr.Cs = t(I) %*% G.sr
  mu1 = G.sr.Cs[1,] / n1
  mu2 = G.sr.Cs[2,] / n2
  A = G.sr.inv %*% I
  Q = A %*% solve(crossprod(A)) %*% t(A)
  Sigma.hat =  (G.sr %*% R_I %*% G.sr + lambda * Q) / n
  Sinv = solve(Sigma.hat)

  Beta1 = Sinv %*% as.matrix(mu2 - mu1)
  Beta0 = log(prior[2]/prior[1])- 0.5*t(mu2 + mu1)%*%Beta1

  R0 = R_I %*% G.sr
  Z0 = G.sr.inv - Q%*%G.sr.inv
  D = matrix(c(-n,0,0,n),2,2)
  
  beta0.LOO = rep(0, n)
  scores.LOO = rep(0,n)
  for (i in 1:n) {
    mu1drop = if (I[i,1] == 1) (G.sr.Cs[1,] - G.sr[i,])/(n1-1) else mu1
    mu2drop = if (I[i,2] == 1) (G.sr.Cs[2,] - G.sr[i,])/(n2-1) else mu2
    mudropdiff = mu2drop - mu1drop
    w = Z0[,i] * sqrt(lambda / sum(Z0[,i]^2))
    v = R0[i,]/sqrt(R_I[i,i])
    U = cbind(v, w)
    SinvU = Sinv%*%U
    beta1 = Sinv%*%mudropdiff - SinvU %*% (solve(D+t(U)%*%SinvU) %*% (t(SinvU) %*% mudropdiff))
    beta0 = beta0.LOO[i] = log(prior[2]/prior[1]) - 0.5*t(mu2drop + mu1drop)%*%beta1
    scores.LOO[i] = G.sr[i,,drop=F]%*%beta1 + beta0
  }

  return(list("beta1" = as.vector(G.sr.inv %*% Beta1),
              "beta0" = as.numeric(Beta0),
              "beta0.LOO" = beta0.LOO,
              "scores.LOO" = scores.LOO))
}