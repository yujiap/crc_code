## List containing:  G.inv, G.sr.inv, G.sr, H, GinvH, lambda, ZZt.inv
complete.precomputed = function(Z, I, min.eig.ratio, precomputed.matrices = NULL)
{
  ## For testing purposes only!
  # min.eig.ratio = 0
  
  ## Reconstruct T. This assumes I = cbind(as.numeric(T==-1), as.numeric(T==1)).
  T = I %*% c(-1, 1)

  ## Current notation.  To discuss.
  ##   -- ZZt:      ZZ'
  ##   -- G:        A (potentially) regularized version of ZZt that gets used in crcL and cross resisidualization
  ##   -- N/A:      A (potentially) regularized version of ZZt that gets used in H
  ##   -- N/A:      A (potentially) regularized version of ZZt that gets used in the fudge factor.
  ##   -- G0:       Unused
  ##   -- ZZt.eval  eigenvalues of ZZ' 
  ##   -- ZZt.evec  eigenvectors of ZZ'
  
  ## We check precomputed.matrices for these objects. TODO: ensure consistency!
  ##   -- lambda
  ##   -- ZZt
  ##   -- ZZt.eval
  ##   -- ZZt.evec
  ##   -- ZZt.inv
  ##   ** G.inv
  ##   ** G.sr
  ##   ** G.sr.inv
  ##   ** H
  ##   ** GinvH
  
  if (is.null(precomputed.matrices$ZZt.eval) | is.null(precomputed.matrices$ZZt.evec))
  {
    ZZt = if (is.null(precomputed.matrices$ZZt)) tcrossprod(Z) else precomputed.matrices$ZZt
    eigen.ZZt = eigen(ZZt)
    ZZt.eval  = eigen.ZZt$values
    ZZt.evec  = eigen.ZZt$vectors
  } else {
    ZZt.eval = precomputed.matrices$ZZt.eval
    ZZt.evec = precomputed.matrices$ZZt.evec
  }
  ZZt.inv  = if (is.null(precomputed.matrices$ZZt.inv)) ZZt.evec %*% ((1/ZZt.eval) * t(ZZt.evec)) else precomputed.matrices$ZZt.inv
  lambda   = if (is.null(precomputed.matrices$lambda)) median(ZZt.eval) else precomputed.matrices$lambda
  
  ## G regularization
  median.ev = median(ZZt.eval)
  r         = ZZt.eval / median.ev
  G.eval    = sapply(1:length(r), function(i) {
    if (r[i] < min.eig.ratio) r[i] = median.ev * min.eig.ratio else ZZt.eval[i]
  })
  G.inv    = if (is.null(precomputed.matrices$G.inv)) ZZt.evec %*% ((1/G.eval) * t(ZZt.evec)) else precomputed.matrices$G.inv
  G.sr     = if (is.null(precomputed.matrices$G.sr)) ZZt.evec %*% (sqrt(G.eval) * t(ZZt.evec)) else precomputed.matrices$G.sr
  G.sr.inv = if (is.null(precomputed.matrices$G.sr.inv)) ZZt.evec %*% ((1/sqrt(G.eval)) * t(ZZt.evec)) else precomputed.matrices$G.sr.inv

  if (is.null(precomputed.matrices$H) | is.null(precomputed.matrices$GinvH))
  {
    G.invT = G.inv %*% T
  }
  H = if (is.null(precomputed.matrices$H)) T %*% solve(t(T) %*% G.invT) %*% t(G.invT) else precomputed.matrices$H
  GinvH = if (is.null(precomputed.matrices$GinvH)) G.invT %*% solve(t(T) %*% G.invT) %*% t(G.invT) else precomputed.matrices$GinvH
  return(list("G.inv"=G.inv,
              "G.sr.inv"=G.sr.inv,
              "G.sr"=G.sr,
              "H"=H,
              "GinvH"=GinvH,
              "lambda"=lambda,
              "ZZt.inv"=ZZt.inv))
}
