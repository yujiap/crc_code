## Remove this once we start using roxygen2
dyn.load("src/crc.so")

# #' @useDynLib crc cncore1_
cncore1 = function(Cn, Ginv, Gbinv, GinvH, GbinvH, H, m){
		ret = .C("cncore1_",
				Cn = as.double(Cn),
				Ginv=as.double(Ginv),
				Gbinv=as.double(Gbinv),
				GinvH=as.double(GinvH),
				GbinvH=as.double(GbinvH),
				H=as.double(H),
				m=as.integer(m))[[1]]
		return(matrix(ret, m, m))
}

# #' @useDynLib crc cncore2_
cncore2 = function(Cn, Ginv, GinvH, H, m){
		ret = .C("cncore2_",
				Cn = as.double(Cn),
				Ginv=as.double(Ginv),
				GinvH=as.double(GinvH),
				H=as.double(H),
				m=as.integer(m))[[1]]
		return(matrix(ret, m, m))
}

# #' @useDynLib crc cncore3_
cncore3 = function(X,
					Ginv, Gbinv,
					H, a, b, solveXtGinvX,
					A, B,
					m, p){
		ret = .C("cncore3_",
				X=as.double(X),
				Ginv=as.double(Ginv),
				Gbinv=as.double(Gbinv),
				H=as.double(H),
				a=as.double(a),
				b=as.double(b),
				solveXtGinvX=as.double(solveXtGinvX),
				A = as.double(A),
				B = as.double(B),
				m=as.integer(m),
				p=as.integer(p))[[2]]
		return(matrix(ret, m, m))
}

# #' @useDynLib crc cncore4_
cncore4 = function(X,
					Ginv, Gbinv,
					H, a, b, solveXtGinvX,
					m, p){
		ret = .C("cncore4_",
				X=as.double(X),
				Ginv=as.double(Ginv),
				Gbinv=as.double(Gbinv),
				H=as.double(H),
				a=as.double(a),
				b=as.double(b),
				solveXtGinvX=as.double(solveXtGinvX),
				m=as.integer(m),
				p=as.integer(p))[[2]]
		return(matrix(ret, m, m))
}

# #' @useDynLib crc cncore5_
cncore5 = function(X,
					Ginv,
					H, a, solveXtGinvX,
					A, B,
					m, p){
		ret = .C("cncore5_",
				X=as.double(X),
				Ginv=as.double(Ginv),
				H=as.double(H),
				a=as.double(a),
				solveXtGinvX=as.double(solveXtGinvX),
				A = as.double(A),
				B = as.double(B),
				m=as.integer(m),
				p=as.integer(p))[[2]]
		return(matrix(ret, m, m))
}

# #' @useDynLib crc cncore6_
cncore6 = function(X,
					Ginv,
					H, a, solveXtGinvX,
					m, p){
		ret = .C("cncore6_",
				X=as.double(X),
				Ginv=as.double(Ginv),
				H=as.double(H),
				a=as.double(a),
				solveXtGinvX=as.double(solveXtGinvX),
				m=as.integer(m),
				p=as.integer(p))[[2]]
		return(matrix(ret, m, m))
}
