confusionMat = function(T, T.hat){
  mat = table(factor(T), factor(T.hat))
  return(mat)
}