crcS = function(I, G.inv, ZZt.inv, H, C, Z, S.grid, L.LOO, prior) {
  n = nrow(I)
  n1 = sum(I[,1])
  n2 = sum(I[,2])
  p = ncol(Z)

  S = C %*% Z # may move this out, bc we need it to calculate lambda for crcL
  Cs = t(I) %*% S # [C]ol[s]ums of S
  Cs.sq = t(I) %*% S^2 # [C]ol[s]ums of S [sq]uared
  Mu1 = Cs[1,] / n1
  Mu2 = Cs[2,] / n2
  ss1 = Cs.sq[1,] - Cs[1,]^2/n1
  ss2 = Cs.sq[2,] - Cs[2,]^2/n2
  M = ZZt.inv %*% Z # for correcting LOO group means

  nN = length(S.grid)
  beta0.LOO_N = matrix(0, n, nN)
  scores.LOO_N = matrix(0, n, nN)

  for (i in 1:n) { # check which is faster, for vs. sapply. also beware scope
    sigmas2 = downdatePooledVar(S, I, Cs, Cs.sq, ss1, ss2, i)
    mu1 = if (I[i,1]) (Cs[1,] - S[i,])/(n1-1) else Mu1
    mu2 = if (I[i,2]) (Cs[2,] - S[i,])/(n2-1) else Mu2
    n1.n2 = colSums(I[-i,])
    c = diag(1/n1.n2) %*% t(I[-i,]) %*% C[-i,i] # test c == c(c1, c2)
    mu1 = mu1 - (c[1] / ZZt.inv[i,i]) * M[i,]
    mu2 = mu2 - (c[2] / ZZt.inv[i,i]) * M[i,]
    tdrop = ((mu2 - mu1) / sqrt(sigmas2)) * sqrt((n1.n2[1]*n1.n2[2])/(n-1))
    toporder = order(abs(tdrop), decreasing = T)
    for (j in 1:nN) {
      N = S.grid[j]
      topN = toporder[1:N]
      beta1 = (mu2[topN] - mu1[topN]) / sigmas2[topN]
      beta0 = beta0.LOO_N[i,j] = log(prior[2]/prior[1]) - 0.5 * sum((mu2[topN] + mu1[topN])*beta1)
      scores.LOO_N[i,j] = S[i, topN, drop = F] %*% beta1 + beta0
    }
  }
  
  sigmas2 = (ss1 + ss2) / (n-2)
  t = (Mu2 - Mu1) / sqrt(sigmas2 * n/(n1*n2)) # recheck
  choose.out = choose_S_scores(scores.LOO_N - beta0.LOO_N, L.LOO, I)
  idx = choose.out$idx
  topN = order(abs(t), decreasing = T)[1:S.grid[idx]]
  beta1 = (Mu2[topN] - Mu1[topN]) / sigmas2[topN]
  beta0 = log(prior[2]/prior[1]) - 0.5*sum((Mu2[topN] + Mu1[topN])*beta1)
  
  beta1.S.S = rep(0, p)
  beta1.S.S[topN] = beta1
  beta1.S.Z = beta1.S.S - (t(Z) %*% (G.inv %*% ((diag(n) - H) %*% (Z %*% beta1.S.S))))

  return(list("beta1.S.S"=as.vector(beta1.S.S),
              "beta1.S.Z"=as.vector(beta1.S.Z),
              "beta0"=beta0, 
              "beta0.LOO"=beta0.LOO_N[,idx],
              "scores.LOO"=scores.LOO_N[,idx],
              "selected.idx"=topN,
              "v"=choose.out$v
              ))
}
