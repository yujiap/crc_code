downdatePooledVar = function(Y, I, Cs, Cs.sq, ss1, ss2, i) {
  n = nrow(I)
  n1 = sum(I[,1])
  n2 = sum(I[,2])
  
  downdateSS = function(colsums, colsums2, yi, n) {
    colsums_drop = colsums - yi
    colsums2_drop = colsums2 - yi^2
    ss_drop = colsums2_drop - colsums_drop^2/(n-1)
    return(ss_drop)
  }
  
  ss1 = if(I[i,1]) downdateSS(Cs[1,], Cs.sq[1,], Y[i,], n1) else ss1
  ss2 = if (I[i,2]) downdateSS(Cs[2,], Cs.sq[2,], Y[i,], n2) else ss2
  return((ss1 + ss2) / (n-3))
}