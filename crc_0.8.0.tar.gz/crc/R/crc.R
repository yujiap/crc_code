#' CRC: Cross-residualization classifier
#'
#' Fits the CRC.
#'
#' @param Z Feature matrix, with observations as rows and features as columns. Predictors
#' should not be standardized.
#' @param classes Vector of class labels. Must be binary.
#' @param prior Vector of class prior probabilities for class -1 and 1, respectively.
#' @param precomputed.matrices A list containining precomputed matrices, if any. NULL by default.
#' 
#' @return \item{class_names}{A vector containing the names of the classes.}
#' @return \item{beta1.S}{Vector of feature weights for CRC-S.}
#' @return \item{beta0.S}{Offset/intercept for CRC-S.}
#' @return \item{beta1.L}{Vector of feature weights for CRC-L.}
#' @return \item{beta0.L}{Offset/intercept for CRC-L.}
#' @return \item{beta1.C}{Vector of weights for CRC.}
#' @return \item{beta0.C}{Offset/intercept for CRC.}
#' @return \item{S.scores.LOO}{Vector of leave-one-out CRC-S scores.}
#' @return \item{L.scores.LOO}{Vector of leave-one-out CRC-L scores.}
#' @return \item{C.scores}{Vector of CRC scores.}
#' @return \item{est.acc.S}{An estimate of the accuracy of CRC-S based on the leave-one-out CRC-S scores.}
#' @return \item{est.acc.L}{An estimate of the accuracy of CRC-L based on the leave-one-out CRC-L scores.}
#' @return \item{est.acc.C}{An estimate of the accuracy of CRC based on the CRC scores}
#' @return \item{cm.S}{Confusion matrix for CRC-S.}
#' @return \item{cm.L}{Confusion matrix for CRC-L.}
#' @return \item{cm.C}{Confusion matrix for CRC.}
#' @return \item{S.selected}{The number of features selected by CRC-S.}
#' @return \item{S.grid}{The grid used for tuning N within the CRC-S (feature selection). The default grid
#' starts at 1 and is capped at p, the number of features. Grid spacings increase by 0.5 on the log2 scale.}
#' @return \item{lambda}{Penalty used in the regularized LDA fit for CRC-L.}
#' @return \item{C}{The cross-residualization operator.}
#' @return \item{L.fit}{Intermediary fit of CRC-L.}
#' @return \item{S.fit}{Intermediary fit of CRC-S.}
#' @return \item{C.fit}{Intermediary fit of CRC.}
#'
#'@details If certain large matrices have already been computed,
#' it can be computationally advantageous to pass these into the function via the precomputed.matrices argument
#' so that CRC does not recompute these large matrices. This feature is currently in development.
#' @export

crc = function(Z, classes, prior = NULL, precomputed.matrices = NULL, S.grid = "default", min.eig.ratio = 1)
{
  ## Check args?

  ## Variables that need to be defined: I, prior, S.grid
  I      = get_I(classes)        # I is the class indicator matrix 
  prior  = get_prior(prior, I)   # Convert "prior" to a numerical vector.
  S.grid = get_S.grid(S.grid, Z) # Convert "S.grid" to a numerical vector.
  
  ## List containing:  G.inv, G.sr.inv, G.sr, H, GinvH, lambda, ZZt.inv
  PC = complete.precomputed(Z, I, min.eig.ratio, precomputed.matrices)    

  ## Operator
  C = fastCR(PC$G.inv, PC$H, PC$GinvH, Gb.inv = NULL, GbinvH = NULL)
 
  ## crc-L
  L.fit = crcL(I, PC$G.sr.inv, PC$G.sr, PC$lambda, prior)   # Returns: beta1 (ndim), beta0, beta0.LOO, scores.LOO
  L.LOO = L.fit$scores.LOO - L.fit$beta0.LOO

  ## crc-S
  S.fit = crcS(I, PC$G.inv, PC$ZZt.inv, PC$H, C, Z, S.grid, L.LOO, prior)   # Returns: beta1.S.S, beta1.S.Z, beta0, beta0.LOO, scores.LOO, selected.idx, v
  S.LOO = S.fit$scores.LOO - S.fit$beta0.LOO 
  
  ## crc-C
  C.fit = crcC(I, S.LOO, L.LOO, prior)   # Returns: beta1, beta0, scores
  C.scores = C.fit$scores
  
  ## Calculate betas
  beta1.S = S.fit$beta1.S.Z
  beta1.L = as.vector(t(Z) %*% L.fit$beta1)
  beta1.C = C.fit$beta1[1]*beta1.S + C.fit$beta1[2]*beta1.L
  beta0.S = S.fit$beta0
  beta0.L = L.fit$beta0
  beta0.C = C.fit$beta0

  ## Wrap up
  # Estimated accuracies. For C, this isn't quite kosher -- discuss.
  # TODO: Check goodness, allow for > 2 classes. Be careful w/ changes to T/I.
  pred.S = ifelse(S.fit$scores.LOO > 0, 1, -1)
  pred.L = ifelse(L.fit$scores.LOO > 0, 1, -1)
  pred.C = ifelse(C.fit$scores > 0, 1, -1)
  est.acc.S = mean(pred.S==classes)
  est.acc.L = mean(pred.L==classes)
  est.acc.C = mean(pred.C==classes)
  cm.S = confusionMat(classes, pred.S)
  cm.L = confusionMat(classes, pred.L)
  cm.C = confusionMat(classes, pred.C)

  return(list("class_names"=colnames(I),
              "beta1.S"=beta1.S, "beta0.S"=beta0.S,
              "beta1.L"=beta1.L, "beta0.L"=beta0.L,
              "beta1.C"=beta1.C, "beta0.C"=beta0.C,
              "S.scores.LOO"=S.fit$scores.LOO,
              "L.scores.LOO"=L.fit$scores.LOO,
              "C.scores"=C.fit$scores,
              ## maybe some estimated accuracies?  specificities, sensitivies, confusion?
              "est.acc.S"=est.acc.S,
              "est.acc.L"=est.acc.L,
              "est.acc.C"=est.acc.C,
              "cm.S"=cm.S,
              "cm.L"=cm.L,
              "cm.C"=cm.C,
              ## maybe return some other things if requested by user, e.g. below?
              "S.selected"=S.fit$selected.idx,
              "S.grid"=S.grid,
              "lambda"=PC$lambda,
              # any other tuning stuff?
              "C"=C,
              "L.fit"=L.fit,
              "S.fit"=S.fit,              
              "C.fit"=C.fit
              ))
}
