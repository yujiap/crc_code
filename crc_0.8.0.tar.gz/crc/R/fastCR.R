#' Fast crossresidualization
#'
#' @param G.inv Gram matrix of observations.
#' @param H The matrix H.
#' @param GinvH The matrix G.inv %*% H.
#' @param Gb.inv Gram matrix of negative controls for RUV-B. By default, this is NULL, as
#' we assume Gb.inv = G.inv.
#' @param GbinvH The matrix Gb.inv %*% H. By default, this is NULL, as
#' we assume Gb.inv = G.inv.
#' 
#' @return The cross-residualization operator, which will be a nxn matrix.
#' @keywords internal

fastCR = function(G.inv, H, GinvH, Gb.inv=NULL, GbinvH=NULL) {
  if ((is.null(Gb.inv) + is.null(GbinvH)) == 1) {
    stop("Gb.inv, GbinvH must be either both null or both non-null")
  }
  n = nrow(G.inv)
  Cn = matrix(0, n, n)
  if (is.null(Gb.inv) & is.null(GbinvH)) {
    return(cncore2(Cn, G.inv, GinvH, H, n))
  } else {
    return(cncore1(Cn, G.inv, Gb.inv, GinvH, GbinvH, H, n))
  }
}