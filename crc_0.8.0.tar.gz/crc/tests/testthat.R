library(testthat)
library(crc)

test_check("crc")
