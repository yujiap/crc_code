## Remember to devtools::load_all() before devtools::test()
## For data generation
set.seed(12)

test_that("n1 = n2, uniform prior, capN >= 10", {
  Z = matrix(rnorm(10*21), 10, 21)
  T = c(rep(-1,5), rep(1,5))
  prior = c(0.5, 0.5)
  cap.N = 21
  out = crc(Z = Z, classes = T, prior = prior, S.grid = "default")
  expect_equal_to_reference(out, "ref1.RDS")
})

test_that("n1 != n2, uniform prior, capN >= 10", {
  Z = matrix(rnorm(10*21), 10, 21)
  T = c(rep(-1,3), rep(1,7))
  prior = c(0.5, 0.5)
  cap.N = 21
  out = crc(Z = Z, classes = T, prior = prior, S.grid = "default")
  expect_equal_to_reference(out, "ref2.RDS")
})

test_that("n1 = n2, non-uniform prior, capN >= 10", {
  Z = matrix(rnorm(10*21), 10, 21)
  T = c(rep(-1,5), rep(1,5))
  prior = c(0.6, 0.4)
  cap.N = 21
  out = crc(Z = Z, classes = T, prior = prior, S.grid = "default")
  expect_equal_to_reference(out, "ref3.RDS")
})

test_that("n1 != n2, non-uniform prior, capN >= 10", {
  Z = matrix(rnorm(10*21), 10, 21)
  T = c(rep(-1,3), rep(1,7))
  prior = c(0.6, 0.4)
  cap.N = 21
  out = crc(Z = Z, classes = T, prior = prior, S.grid = "default")
  expect_equal_to_reference(out, "ref4.RDS")
})

test_that("n odd", {
  Z = matrix(rnorm(5*11), 5, 11)
  T = c(rep(-1,3), rep(1,2))
  prior = c(0.4, 0.6)
  cap.N = 11
  out = crc(Z = Z, classes = T, prior = prior, S.grid = "default")
  expect_equal_to_reference(out, "ref5.RDS")
})

test_that("1 < cap.N <=10", {
  Z = matrix(rnorm(5*11), 5, 11)
  T = c(rep(-1,3), rep(1,2))
  prior = c(0.4, 0.6)
  cap.N = 3
  out = crc(Z = Z, classes = T, prior = prior, S.grid = "default")
  expect_equal_to_reference(out, "ref6.RDS")
})

# test_that("cap.N = 1", {
#     Z = matrix(rnorm(5*11), 5, 11)
#     T = c(rep(-1,3), rep(1,2))
#     prior = c(0.4, 0.6)
#     cap.N = 1
#   out = crc(Z = Z, classes = T, prior = prior, S.grid = "default")
#   expect_equal_to_reference(out, "ref7.RDS")
# })
